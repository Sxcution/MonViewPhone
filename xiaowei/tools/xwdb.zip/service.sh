#!/system/bin/sh

exec /system/bin/xwdb
